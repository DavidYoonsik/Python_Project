from distutils.core import setup

setup(name='hello', version='1.0', py_modules=['app2'],)